﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Text.RegularExpressions; // ! ! !

namespace validateProj
{
    public partial class Form1 : Form
    {
        Regex regexNum = new Regex(@"[^0-9]");
        Regex regexCir = new Regex(@"[^а-яА-Я\s]");

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string t = textBox1.Text;
            int cursorPos = textBox1.SelectionStart; //запоминаем где был курсор во время ввода иначе курсов будет переходить в начало или конец строки

            if(regexNum.IsMatch(t))
            {
                textBox1.Text = regexNum.Replace(t, "");
                textBox1.SelectionStart = cursorPos - 1; // удалили символ сместились на один
            }
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int cursorPos = textBox2.SelectionStart;

            if (regexCir.IsMatch(textBox2.Text))
            {
                textBox2.Text = regexCir.Replace(textBox2.Text, "");
                textBox2.SelectionStart = cursorPos - 1; // удалили символ сместились на один
            }
        }
    }
}
