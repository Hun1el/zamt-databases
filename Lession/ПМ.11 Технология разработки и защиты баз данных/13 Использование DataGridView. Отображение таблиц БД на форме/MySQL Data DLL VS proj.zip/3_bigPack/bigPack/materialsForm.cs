﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //подключаем библиотеку в Reference -> C:\ProgramFiles\MySql\Connector Net\Assembly\net framework 4.5

namespace bigPack
{
    public partial class materialsForm : Form
    {
        public materialsForm()
        {
            InitializeComponent();
        }
        //соблюдаем camelCase во всём
        private void materialsFormLoad(object sender, EventArgs e)
        {
            //connectionString -> host=localhost;uid=root;pwd=;database=test
            MySqlConnection con = new MySqlConnection(@"host=localhost;user id=root;password=;database=test");
            con.Open();

            //!!!!! строк закоментировано кода не должно быть
            //MessageBox.Show(con.State.ToString());

            con.Close();
        }

        //сработает при вводе текста в поле
        private void searchTextTextChanged(object sender, EventArgs e)
        {
            string strSeach = searchText.Text;

        }
    }
}
